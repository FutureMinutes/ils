// netlify/functions/_shared.js
// Gemeinsamer Supabase-Client für alle Netlify Functions

const { createClient } = require('@supabase/supabase-js');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY,
  { auth: { persistSession: false } }
);

const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME';

// CORS Headers für alle Responses
const CORS = {
  'Access-Control-Allow-Origin':  '*',
  'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type,Authorization',
  'Content-Type': 'application/json',
};

function ok(data, status = 200) {
  return { statusCode: status, headers: CORS, body: JSON.stringify(data) };
}
function err(msg, status = 400) {
  return { statusCode: status, headers: CORS, body: JSON.stringify({ error: msg }) };
}
function cors() {
  return { statusCode: 204, headers: CORS, body: '' };
}

// JWT erstellen (Azubi-Login)
function signToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '7d' });
}

// JWT prüfen → gibt Student-Objekt zurück oder null
function verifyToken(authHeader) {
  if (!authHeader?.startsWith('Bearer ')) return null;
  try { return jwt.verify(authHeader.slice(7), JWT_SECRET); }
  catch { return null; }
}

module.exports = { supabase, ok, err, cors, signToken, verifyToken, bcrypt, CORS };
