// netlify/functions/results.js
// Routes: POST /api/results             – Ergebnis speichern (Azubi nach Test)
//         GET  /api/results             – alle Ergebnisse (Ausbilder)
//         GET  /api/results?test_id=X   – Ergebnisse für Test (Ausbilder)
//         GET  /api/results?my=1        – eigene Ergebnisse (Azubi)
//         DELETE /api/results/:id       – löschen (Ausbilder)

const { supabase, ok, err, cors, verifyToken } = require('./_shared');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();

  const path  = event.path.replace(/.*\/results\/?/, '');
  const id    = path.split('/').filter(Boolean)[0];
  const body  = event.body ? JSON.parse(event.body) : {};
  const user  = verifyToken(event.headers.authorization);
  const qs    = event.queryStringParameters || {};

  // ── POST /api/results – Ergebnis speichern ────────────────────────────
  // Azubi muss eingeloggt sein ODER Gast-Submission (nur Name)
  if (event.httpMethod === 'POST') {
    const { test_id, student_name, score, passed, earned_pts,
            total_pts, correct, total_q, answers, duration_sec } = body;

    if (!test_id)      return err('test_id erforderlich');
    if (!student_name) return err('student_name erforderlich');
    if (score === undefined) return err('score erforderlich');

    // Test prüfen ob er existiert und veröffentlicht ist
    const { data: test, error: tErr } = await supabase
      .from('tests').select('id, published').eq('id', test_id).single();
    if (tErr || !test) return err('Test nicht gefunden', 404);
    if (!test.published && (!user || user.role !== 'ausbilder'))
      return err('Test nicht veröffentlicht', 403);

    const insert = {
      test_id,
      student_id:   user?.id || null,
      student_name: student_name.trim(),
      score:        Math.round(score * 100) / 100,
      passed:       !!passed,
      earned_pts:   earned_pts || 0,
      total_pts:    total_pts  || 0,
      correct:      correct    || 0,
      total_q:      total_q    || 0,
      answers:      answers    || null,
      duration_sec: duration_sec || null,
    };

    const { data, error } = await supabase.from('test_results').insert(insert).select().single();
    if (error) return err(error.message, 500);
    return ok(data, 201);
  }

  // ── GET /api/results – eigene Ergebnisse (Azubi) ─────────────────────
  if (event.httpMethod === 'GET' && !id && qs.my === '1') {
    if (!user) return err('Nicht angemeldet', 401);
    const { data, error } = await supabase
      .from('test_results')
      .select(`id, test_id, student_name, score, passed, earned_pts, total_pts,
               correct, total_q, duration_sec, submitted_at,
               tests(title, subtitle)`)
      .eq('student_id', user.id)
      .order('submitted_at', { ascending: false });
    if (error) return err(error.message, 500);
    return ok(data);
  }

  // ── Ab hier: Ausbilder erforderlich ──────────────────────────────────
  if (!user) return err('Nicht angemeldet', 401);
  if (user.role !== 'ausbilder') return err('Keine Berechtigung', 403);

  // ── GET /api/results?test_id=X ────────────────────────────────────────
  if (event.httpMethod === 'GET' && !id) {
    let query = supabase
      .from('test_results')
      .select(`id, test_id, student_id, student_name, score, passed,
               earned_pts, total_pts, correct, total_q, answers,
               duration_sec, submitted_at, tests(title, subtitle)`)
      .order('submitted_at', { ascending: false });

    if (qs.test_id) query = query.eq('test_id', qs.test_id);

    const { data, error } = await query;
    if (error) return err(error.message, 500);
    return ok(data);
  }

  // ── DELETE /api/results/:id ───────────────────────────────────────────
  if (event.httpMethod === 'DELETE' && id) {
    const { error } = await supabase.from('test_results').delete().eq('id', id);
    if (error) return err(error.message, 500);
    return ok({ deleted: id });
  }

  return err('Route nicht gefunden', 404);
};
