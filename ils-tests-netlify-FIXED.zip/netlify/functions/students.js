// netlify/functions/students.js
// Routes: POST /api/students/login
//         POST /api/students/register
//         GET  /api/students          (nur Ausbilder)
//         PUT  /api/students/:id      (nur Ausbilder)
//         DELETE /api/students/:id   (nur Ausbilder)

const { supabase, ok, err, cors, signToken, verifyToken, bcrypt } = require('./_shared');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();

  const path  = event.path.replace(/.*\/students\/?/, '');
  const parts = path.split('/').filter(Boolean);
  const id    = parts[0];
  const sub   = parts[1]; // z.B. 'login'
  const body  = event.body ? JSON.parse(event.body) : {};
  const auth  = event.headers.authorization;

  // ── POST /api/students/login ─────────────────────────────────────────
  if (event.httpMethod === 'POST' && (path === 'login' || sub === 'login')) {
    const { email, password } = body;
    if (!email || !password) return err('E-Mail und Passwort erforderlich');

    const { data: student, error } = await supabase
      .from('students')
      .select('*')
      .eq('email', email.toLowerCase().trim())
      .eq('active', true)
      .single();

    if (error || !student) return err('E-Mail oder Passwort falsch', 401);

    // Erstes Login mit CHANGE_VIA_API → Passwort setzen
    if (student.password === 'CHANGE_VIA_API') {
      return err('Bitte zuerst Passwort über den Administrator setzen', 403);
    }

    const valid = await bcrypt.compare(password, student.password);
    if (!valid) return err('E-Mail oder Passwort falsch', 401);

    // last_login aktualisieren
    await supabase.from('students').update({ last_login: new Date().toISOString() }).eq('id', student.id);

    const token = signToken({ id: student.id, name: student.name, role: student.role });
    return ok({ token, student: { id: student.id, name: student.name, email: student.email, role: student.role } });
  }

  // ── POST /api/students/register ──────────────────────────────────────
  if (event.httpMethod === 'POST' && path === 'register') {
    const { name, email, password } = body;
    if (!name || !email || !password) return err('Name, E-Mail und Passwort erforderlich');
    if (password.length < 6) return err('Passwort muss mindestens 6 Zeichen haben');

    const hash = await bcrypt.hash(password, 10);
    const { data, error } = await supabase
      .from('students')
      .insert({ name: name.trim(), email: email.toLowerCase().trim(), password: hash, role: 'azubi' })
      .select('id, name, email, role')
      .single();

    if (error) {
      if (error.code === '23505') return err('Diese E-Mail ist bereits registriert', 409);
      return err('Registrierung fehlgeschlagen: ' + error.message, 500);
    }

    const token = signToken({ id: data.id, name: data.name, role: data.role });
    return ok({ token, student: data }, 201);
  }

  // ── Ab hier: Ausbilder-Authentifizierung erforderlich ────────────────
  const user = verifyToken(auth);
  if (!user) return err('Nicht angemeldet', 401);
  if (user.role !== 'ausbilder') return err('Keine Berechtigung', 403);

  // ── GET /api/students ─────────────────────────────────────────────────
  if (event.httpMethod === 'GET' && !id) {
    const { data, error } = await supabase
      .from('students')
      .select('id, name, email, role, active, created_at, last_login')
      .order('name');
    if (error) return err(error.message, 500);
    return ok(data);
  }

  // ── PUT /api/students/:id ─────────────────────────────────────────────
  if (event.httpMethod === 'PUT' && id) {
    const updates = {};
    if (body.name)     updates.name     = body.name;
    if (body.role)     updates.role     = body.role;
    if (body.active !== undefined) updates.active = body.active;
    if (body.password) updates.password = await bcrypt.hash(body.password, 10);

    const { data, error } = await supabase
      .from('students').update(updates).eq('id', id).select().single();
    if (error) return err(error.message, 500);
    return ok(data);
  }

  // ── DELETE /api/students/:id ──────────────────────────────────────────
  if (event.httpMethod === 'DELETE' && id) {
    const { error } = await supabase.from('students').delete().eq('id', id);
    if (error) return err(error.message, 500);
    return ok({ deleted: id });
  }

  return err('Route nicht gefunden', 404);
};
