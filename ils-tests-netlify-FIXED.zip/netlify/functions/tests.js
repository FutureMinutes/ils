// netlify/functions/tests.js
// Routes: GET    /api/tests            – alle Tests (Ausbilder) / veröffentlichte (Azubi)
//         GET    /api/tests/:id        – einzelner Test
//         POST   /api/tests            – Test erstellen (Ausbilder)
//         PUT    /api/tests/:id        – Test bearbeiten (Ausbilder)
//         DELETE /api/tests/:id        – Test löschen (Ausbilder)
//         POST   /api/tests/:id/publish – Test veröffentlichen

const { supabase, ok, err, cors, verifyToken } = require('./_shared');

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') return cors();

  const path  = event.path.replace(/.*\/tests\/?/, '');
  const parts = path.split('/').filter(Boolean);
  const id    = parts[0];
  const sub   = parts[1]; // z.B. 'publish'
  const body  = event.body ? JSON.parse(event.body) : {};
  const user  = verifyToken(event.headers.authorization);

  // ── GET /api/tests/:id – ÖFFENTLICH für Azubis ───────────────────────
  if (event.httpMethod === 'GET' && id && !sub) {
    const { data, error } = await supabase
      .from('tests')
      .select('id, title, subtitle, instructions, time_limit, pass_percent, shuffle_q, shuffle_a, show_score, questions, published')
      .eq('id', id)
      .single();

    if (error) return err('Test nicht gefunden', 404);
    if (!data.published && (!user || user.role !== 'ausbilder'))
      return err('Dieser Test ist noch nicht veröffentlicht', 403);

    // Wenn nicht Ausbilder: Lösungshinweise aus Antworten entfernen
    if (!user || user.role !== 'ausbilder') {
      data.questions = (data.questions || []).map(q => ({
        ...q,
        answers: q.answers.map(a => ({ id: a.id, text: a.text })), // correct entfernt
      }));
    }

    return ok(data);
  }

  // ── GET /api/tests – Liste ────────────────────────────────────────────
  if (event.httpMethod === 'GET' && !id) {
    let query = supabase.from('tests').select('id, title, subtitle, time_limit, pass_percent, published, created_at, updated_at');
    if (!user || user.role !== 'ausbilder') {
      query = query.eq('published', true); // Azubis sehen nur veröffentlichte
    }
    const { data, error } = await query.order('updated_at', { ascending: false });
    if (error) return err(error.message, 500);
    return ok(data);
  }

  // ── Ab hier: Ausbilder erforderlich ──────────────────────────────────
  if (!user) return err('Nicht angemeldet', 401);
  if (user.role !== 'ausbilder') return err('Keine Berechtigung', 403);

  // ── POST /api/tests/:id/publish ───────────────────────────────────────
  if (event.httpMethod === 'POST' && id && sub === 'publish') {
    const { data, error } = await supabase
      .from('tests')
      .update({ published: !body.unpublish })
      .eq('id', id)
      .select('id, title, published')
      .single();
    if (error) return err(error.message, 500);
    return ok(data);
  }

  // ── POST /api/tests – Neuer Test ──────────────────────────────────────
  if (event.httpMethod === 'POST' && !id) {
    const { title, subtitle, instructions, time_limit, pass_percent,
            shuffle_q, shuffle_a, show_score, questions } = body;
    if (!title) return err('Titel erforderlich');

    const { data, error } = await supabase
      .from('tests')
      .insert({
        title, subtitle, instructions,
        time_limit:   time_limit   ?? 0,
        pass_percent: pass_percent ?? 70,
        shuffle_q:    shuffle_q    ?? false,
        shuffle_a:    shuffle_a    ?? false,
        show_score:   show_score   !== false,
        questions:    questions    || [],
        published:    false,
        created_by:   user.id,
      })
      .select()
      .single();

    if (error) return err(error.message, 500);
    return ok(data, 201);
  }

  // ── PUT /api/tests/:id ────────────────────────────────────────────────
  if (event.httpMethod === 'PUT' && id) {
    const allowed = ['title','subtitle','instructions','time_limit','pass_percent',
                     'shuffle_q','shuffle_a','show_score','questions','published'];
    const updates = {};
    allowed.forEach(k => { if (body[k] !== undefined) updates[k] = body[k]; });

    const { data, error } = await supabase
      .from('tests').update(updates).eq('id', id).select().single();
    if (error) return err(error.message, 500);
    return ok(data);
  }

  // ── DELETE /api/tests/:id ─────────────────────────────────────────────
  if (event.httpMethod === 'DELETE' && id) {
    const { error } = await supabase.from('tests').delete().eq('id', id);
    if (error) return err(error.message, 500);
    return ok({ deleted: id });
  }

  return err('Route nicht gefunden', 404);
};
