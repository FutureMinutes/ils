-- ════════════════════════════════════════════════════════════════════════
--  ILS Lernstandstest – Supabase Schema
--  Ausführen in: Supabase Dashboard → SQL Editor → New Query
-- ════════════════════════════════════════════════════════════════════════

-- Erweiterungen
create extension if not exists "uuid-ossp";
create extension if not exists "pgcrypto";

-- ── Tabelle: students ────────────────────────────────────────────────────
create table if not exists public.students (
  id          uuid primary key default uuid_generate_v4(),
  name        text not null,
  email       text unique not null,
  password    text not null,          -- bcrypt hash (via Netlify Function)
  role        text default 'azubi',   -- 'azubi' | 'ausbilder'
  active      boolean default true,
  created_at  timestamptz default now(),
  last_login  timestamptz
);

comment on table public.students is 'Azubis und Ausbilder';

-- ── Tabelle: tests ───────────────────────────────────────────────────────
create table if not exists public.tests (
  id            uuid primary key default uuid_generate_v4(),
  title         text not null,
  subtitle      text,
  instructions  text,
  time_limit    integer default 0,    -- Minuten, 0 = kein Limit
  pass_percent  integer default 70,
  shuffle_q     boolean default false,
  shuffle_a     boolean default false,
  show_score    boolean default true,
  questions     jsonb not null default '[]',
  published     boolean default false,
  created_by    uuid references public.students(id) on delete set null,
  created_at    timestamptz default now(),
  updated_at    timestamptz default now()
);

comment on table public.tests is 'Multiple-Choice-Tests';
comment on column public.tests.questions is 'Array of {id, text, hint, type, answers:[{id,text,correct}], category, points}';

-- ── Tabelle: test_results ────────────────────────────────────────────────
create table if not exists public.test_results (
  id            uuid primary key default uuid_generate_v4(),
  test_id       uuid not null references public.tests(id) on delete cascade,
  student_id    uuid references public.students(id) on delete set null,
  student_name  text not null,
  score         numeric(5,2) not null,   -- 0.00–100.00 (Prozent)
  passed        boolean not null,
  earned_pts    integer not null,
  total_pts     integer not null,
  correct       integer not null,
  total_q       integer not null,
  answers       jsonb,                   -- [{correct, selected, correct_idx}]
  duration_sec  integer,
  submitted_at  timestamptz default now()
);

comment on table public.test_results is 'Testergebnisse der Azubis';

-- ── Row Level Security ───────────────────────────────────────────────────
alter table public.students   enable row level security;
alter table public.tests       enable row level security;
alter table public.test_results enable row level security;

-- Alle Operationen über den Service Role Key (Netlify Functions)
-- Frontend-Zugriff nur über Netlify Functions, NICHT direkt

-- Policy: Service Role kann alles (für Netlify Functions)
create policy "service_role_students"   on public.students   for all using (true);
create policy "service_role_tests"      on public.tests       for all using (true);
create policy "service_role_results"    on public.test_results for all using (true);

-- ── Hilfsfunktionen ──────────────────────────────────────────────────────

-- updated_at automatisch setzen
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;

create trigger tests_updated_at
  before update on public.tests
  for each row execute function public.set_updated_at();

-- ── Indizes für Performance ───────────────────────────────────────────────
create index if not exists idx_results_test_id   on public.test_results(test_id);
create index if not exists idx_results_student   on public.test_results(student_id);
create index if not exists idx_results_submitted on public.test_results(submitted_at desc);
create index if not exists idx_students_email    on public.students(email);

-- ── Demo-Ausbilder anlegen (Passwort: ILS2025!) ───────────────────────────
-- Passwort-Hash wird über Netlify Function gesetzt, hier Platzhalter:
insert into public.students (name, email, password, role)
values ('Administrator', 'admin@ils-test.de', 'CHANGE_VIA_API', 'ausbilder')
on conflict (email) do nothing;

-- ════════════════════════════════════════════════════════════════════════
--  FERTIG – jetzt netlify.toml und .env ausfüllen
-- ════════════════════════════════════════════════════════════════════════
